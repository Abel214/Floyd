import heapq

class EstadoNodo:
    def __init__(self, etiqueta=None, predecesor="-", estado="Temporal"):
        self.etiqueta = etiqueta
        self.predecesor = predecesor
        self.estado = estado

    def set_estado(self, estado):
        self.estado = estado

    def __repr__(self):
        if self.etiqueta is None:
            return f"[inf, -] ({self.estado})"
        else:
            return f"[{self.etiqueta},{self.predecesor}] ({self.estado})"

class Adyacencia:
    def __init__(self, destino=None, peso=None):
        self.destino = destino
        self.peso = peso

    def get_destino(self):
        return self.destino

    def get_peso(self):
        return self.peso

class GrafoDirigido:
    def __init__(self):
        self.vertices = {}

    def agregar_vertice(self, vertice):
        if vertice not in self.vertices:
            self.vertices[vertice] = []

    def agregar_arista(self, origen, destino, peso):
        self.agregar_vertice(origen)
        self.agregar_vertice(destino)
        self.vertices[origen].append(Adyacencia(destino, peso))

    def inicializar_matrices(self):
        vertices = sorted(self.vertices.keys())
        n = len(vertices)
        
        # Inicializar matrices
        distancias = [[float('inf')] * n for _ in range(n)]
        recorrido = [[0] * n for _ in range(n)]
        
        # Llenar las matrices con los valores iniciales
        for i in range(n):
            for j in range(n):
                if i == j:
                    distancias[i][j] = 0
                    recorrido[i][j] = 0
                else:
                    recorrido[i][j] = j + 1
        
        for origen, adyacencias in self.vertices.items():
            i = vertices.index(origen)
            for adyacencia in adyacencias:
                j = vertices.index(adyacencia.get_destino())
                distancias[i][j] = adyacencia.get_peso()
                if adyacencia.get_peso() != float('inf') and i != j:
                    recorrido[i][j] = j + 1

        return distancias, recorrido, vertices

    def floyd(self, distancias, recorrido, vertices):
        n = len(vertices)
        
        def imprimir_matrices():
            print("Matriz de Distancias:")
            print("    " + " ".join(f"{v:4}" for v in vertices))
            for i, fila in enumerate(distancias):
                print(f"{vertices[i]:4}" + " ".join(f"{d if d != float('inf') else 'inf':4}" for d in fila))
            print("\nMatriz de Recorrido:")
            print("    " + " ".join(f"{v:4}" for v in vertices))
            for i, fila in enumerate(recorrido):
                print(f"{vertices[i]:4}" + " ".join(f"{r:4}" for r in fila))
            print()

        print("Estado Inicial:")
        imprimir_matrices()
        
        # Algoritmo de Floyd-Warshall corregido
        for k in range(n):                                                  
            for i in range(n):
                for j in range(n):
                    if distancias[i][j] > distancias[i][k] + distancias[k][j]:
                        distancias[i][j] = distancias[i][k] + distancias[k][j]
                        recorrido[i][j] = k+1            
            print(f"Después de considerar el vértice {vertices[k]}:")
            imprimir_matrices()

        return distancias, recorrido
def reconstruir_ruta(recorrido, vertices, inicio, fin):
    ruta = []
    i = vertices.index(inicio)
    j = vertices.index(fin)
    if recorrido[i][j] == float('inf'):
        print(f"No hay ruta desde {inicio} hasta {fin}")
        return ruta
    
    def reconstruir_camino(i, j):
        if i != j and recorrido[i][j] != j + 1:
            reconstruir_camino(i, recorrido[i][j] - 1)
            reconstruir_camino(recorrido[i][j] - 1, j)
        else:
            ruta.append(vertices[j])

    ruta.append(inicio)
    reconstruir_camino(i, j)
    return ruta
def main():
    grafo = GrafoDirigido()
    grafo.agregar_arista('1', '2', 3)
    grafo.agregar_arista('2', '1', 3)
    grafo.agregar_arista('2', '4', 5)
    grafo.agregar_arista('4', '2', 5)
    grafo.agregar_arista('1', '3', 10)
    grafo.agregar_arista('3', '1', 10)
    grafo.agregar_arista('3', '4', 6)
    grafo.agregar_arista('4', '3', 6)
    grafo.agregar_arista('4', '5', 4)
    grafo.agregar_arista('5', '4', 4)
    grafo.agregar_arista('3', '5', 15)

    distancias, recorrido, vertices = grafo.inicializar_matrices()
    distancias, recorrido = grafo.floyd(distancias, recorrido, vertices)

    nodo_inicial = input("Ingrese el nodo inicial: ")
    nodo_final = input("Ingrese el nodo final: ")
    
    i = vertices.index(nodo_inicial)
    j = vertices.index(nodo_final)

    print(f"\nLa distancia más corta desde {nodo_inicial} hasta {nodo_final} es: {distancias[i][j]}")

    ruta = reconstruir_ruta(recorrido, vertices, nodo_inicial, nodo_final)
    print(f"La ruta más corta es: {' -> '.join(ruta)}")

if __name__ == "__main__":
    main()